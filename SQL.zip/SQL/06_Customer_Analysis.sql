-- ==========================================
-- Business Question:
-- How many unique customers do we have?
-- ==========================================

SELECT
    COUNT(DISTINCT customer_unique_id) AS unique_customers
FROM customers;

-- ==========================================
-- Business Question:
-- Which states have the highest number of customers?
-- ==========================================

SELECT

    customer_state,

    COUNT(*) AS total_customers

FROM customers

GROUP BY customer_state

ORDER BY total_customers DESC;

-- ==========================================
-- Business Question:
-- Who are the highest-spending customers?
-- ==========================================

SELECT

    c.customer_unique_id,

    ROUND(SUM(op.payment_value),2) AS total_spent

FROM customers c

JOIN orders o
ON c.customer_id = o.customer_id

JOIN order_payments op
ON o.order_id = op.order_id

GROUP BY c.customer_unique_id

ORDER BY total_spent DESC

LIMIT 10;

-- ==========================================
-- Business Question:
-- How many orders has each customer placed?
-- ==========================================

SELECT

    c.customer_unique_id,

    COUNT(o.order_id) AS total_orders

FROM customers c

JOIN orders o
ON c.customer_id = o.customer_id

GROUP BY c.customer_unique_id

ORDER BY total_orders DESC;

-- ==========================================
-- Business Question:
-- Which customers have placed more than one order?
-- ==========================================

SELECT

    c.customer_unique_id,

    COUNT(o.order_id) AS total_orders

FROM customers c

JOIN orders o
ON c.customer_id = o.customer_id

GROUP BY c.customer_unique_id

HAVING COUNT(o.order_id) > 1

ORDER BY total_orders DESC;

-- ==========================================
-- Business Question:
-- How many customers are new vs repeat?
-- ==========================================

SELECT

case

when total_orders =1 then  'New Customer'

Else 'Repeat Customer'

End as customer_type,
count(*) as customers

FROM (

SELECT

    c.customer_unique_id,

    COUNT(o.order_id) AS total_orders

FROM customers c

JOIN orders o
ON c.customer_id = o.customer_id

GROUP BY c.customer_unique_id

) 

GROUP BY customer_type;

-- ==========================================
-- Business Question:
-- What is the average amount spent per customer?
-- ==========================================

SELECT

ROUND(AVG(total_spent),2) AS average_customer_spending

FROM(

SELECT

    c.customer_unique_id,

    SUM(op.payment_value) AS total_spent

FROM customers c

JOIN orders o
ON c.customer_id=o.customer_id

JOIN order_payments op
ON o.order_id=op.order_id

GROUP BY c.customer_unique_id

)t;

-- ==========================================
-- Business Question:
-- What is each customer's lifetime value?
-- ==========================================

SELECT

    c.customer_unique_id,

    COUNT(o.order_id) AS total_orders,

    ROUND(SUM(op.payment_value),2) AS lifetime_value

FROM customers c

JOIN orders o
ON c.customer_id=o.customer_id

JOIN order_payments op
ON o.order_id=op.order_id

GROUP BY c.customer_unique_id

ORDER BY lifetime_value DESC;

-- ==========================================
--Top 10 Customer State by Revenue
-- ==========================================
SELECT

    c.customer_state,

    ROUND(SUM(op.payment_value),2) AS revenue

FROM customers c

JOIN orders o
ON c.customer_id=o.customer_id

JOIN order_payments op
ON o.order_id=op.order_id

GROUP BY c.customer_state

ORDER BY revenue DESC

LIMIT 10;

--Customer Spending Rank

SELECT

    c.customer_unique_id,

    ROUND(SUM(op.payment_value),2) AS total_spent,

    RANK() OVER(

        ORDER BY SUM(op.payment_value) DESC

    ) AS customer_rank

FROM customers c

JOIN orders o
ON c.customer_id=o.customer_id

JOIN order_payments op
ON o.order_id=op.order_id

GROUP BY c.customer_unique_id;