-- ==========================================
-- Business Question:
-- Which products are sold the most?
-- ==========================================

SELECT

    product_id,

    COUNT(*) AS total_quantity_sold

FROM order_items

GROUP BY product_id

ORDER BY total_quantity_sold DESC

LIMIT 10;

-- ==========================================
-- Business Question:
-- Which products generate the highest revenue?
-- ==========================================

SELECT

    product_id,

    ROUND(SUM(price),2) AS revenue

FROM order_items

GROUP BY product_id

ORDER BY revenue DESC

LIMIT 10;

-- ==========================================
-- Business Question:
-- Which product categories generate the highest revenue?
-- ==========================================

SELECT

    ct.product_category_name_english AS category,

    ROUND(SUM(oi.price),2) AS revenue

FROM order_items oi

JOIN products p
ON oi.product_id = p.product_id

JOIN category_translation ct
ON p.product_category_name = ct.product_category_name

GROUP BY category

ORDER BY revenue DESC;

-- ==========================================
-- Business Question:
-- Which categories sell the highest quantity?
-- ==========================================

SELECT

    ct.product_category_name_english,

    COUNT(*) AS quantity_sold

FROM order_items oi

JOIN products p
ON oi.product_id=p.product_id

JOIN category_translation ct
ON p.product_category_name=ct.product_category_name

GROUP BY ct.product_category_name_english

ORDER BY quantity_sold DESC;

-- ==========================================
-- Business Question:
-- What is the average product price by category?
-- ==========================================

SELECT

    ct.product_category_name_english,

    ROUND(AVG(oi.price),2) AS average_price

FROM order_items oi

JOIN products p
ON oi.product_id=p.product_id

JOIN category_translation ct
ON p.product_category_name=ct.product_category_name

GROUP BY ct.product_category_name_english

ORDER BY average_price DESC;


-- ==========================================
-- Business Question:
-- Which products have the highest selling price?
-- ==========================================

SELECT

    product_id,

    MAX(price) AS highest_price

FROM order_items

GROUP BY product_id

ORDER BY highest_price DESC

LIMIT 10;


-- ==========================================
-- Business Question:
-- What percentage of total revenue comes from each category?
-- ==========================================

SELECT

    ct.product_category_name_english,

    ROUND(SUM(oi.price),2) AS revenue,

    ROUND(
        100.0 * SUM(oi.price) /
        SUM(SUM(oi.price)) OVER (),
        2
    ) AS revenue_percentage

FROM order_items oi

JOIN products p
ON oi.product_id = p.product_id

JOIN category_translation ct
ON p.product_category_name = ct.product_category_name

GROUP BY ct.product_category_name_english

ORDER BY revenue DESC;

-- ==========================================
-- Business Question:
-- Rank products based on revenue.
-- ==========================================

SELECT

    product_id,

    ROUND(SUM(price),2) AS revenue,

    RANK() OVER(

        ORDER BY SUM(price) DESC

    ) AS product_rank

FROM order_items

GROUP BY product_id;

-- ==========================================
--Category Revenue Ranking
-- ==========================================

SELECT

    ct.product_category_name_english,

    ROUND(SUM(oi.price),2) AS revenue,

    DENSE_RANK() OVER(

        ORDER BY SUM(oi.price) DESC

    ) AS category_rank

FROM order_items oi

JOIN products p
ON oi.product_id=p.product_id

JOIN category_translation ct
ON p.product_category_name=ct.product_category_name

GROUP BY ct.product_category_name_english;

-- ==========================================
--Top 10 Categories by Quantity Sold
-- ==========================================

SELECT

    ct.product_category_name_english,

    COUNT(*) AS quantity

FROM order_items oi

JOIN products p
ON oi.product_id=p.product_id

JOIN category_translation ct
ON p.product_category_name=ct.product_category_name

GROUP BY ct.product_category_name_english

ORDER BY quantity DESC

LIMIT 10;

--Pareto Analysis (80/20 Rule)

WITH category_sales AS (

SELECT

    ct.product_category_name_english,

    SUM(oi.price) AS revenue

FROM order_items oi

JOIN products p
ON oi.product_id=p.product_id

JOIN category_translation ct
ON p.product_category_name=ct.product_category_name

GROUP BY ct.product_category_name_english

),

pareto AS (

SELECT

    product_category_name_english,

    revenue,

    SUM(revenue) OVER(
        ORDER BY revenue DESC
    ) AS cumulative_revenue,

    SUM(revenue) OVER() AS total_revenue

FROM category_sales

)

SELECT

    product_category_name_english,

    ROUND(revenue,2),

    ROUND(
        cumulative_revenue*100/total_revenue,
        2
    ) AS cumulative_percentage

FROM pareto;


--ABC Product Classification

WITH category_sales AS (

SELECT

    ct.product_category_name_english,

    SUM(oi.price) revenue

FROM order_items oi

JOIN products p
ON oi.product_id=p.product_id

JOIN category_translation ct
ON p.product_category_name=ct.product_category_name

GROUP BY ct.product_category_name_english

),

abc AS (

SELECT

product_category_name_english,

revenue,

SUM(revenue) OVER(
ORDER BY revenue DESC
) cumulative_revenue,

SUM(revenue) OVER() total_revenue

FROM category_sales

)

SELECT

product_category_name_english,

ROUND(revenue,2),

ROUND(
100*cumulative_revenue/total_revenue,
2
) cumulative_percentage,

CASE

WHEN cumulative_revenue <= total_revenue*0.80 THEN 'A'

WHEN cumulative_revenue <= total_revenue*0.95 THEN 'B'

ELSE 'C'

END AS category_class

FROM abc;