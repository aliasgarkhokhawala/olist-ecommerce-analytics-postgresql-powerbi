-- ==========================================
-- Business Question:
-- What is the total revenue generated?
-- ==========================================

SELECT
    ROUND(SUM(payment_value),2) AS total_revenue
FROM order_payments;

-- ==========================================
-- Business Question:
-- What is the average order value?
-- ==========================================

SELECT
    ROUND(AVG(payment_value),2) AS average_order_value
FROM order_payments;


-- ==========================================
-- Business Question:
-- How much revenue is generated every month?
-- ==========================================

SELECT

    TO_CHAR(o.order_purchase_timestamp,'YYYY-MM') AS month,

    ROUND(SUM(op.payment_value),2) AS revenue

FROM orders o

JOIN order_payments op
ON o.order_id = op.order_id

GROUP BY month

ORDER BY month;

-- ==========================================
-- Business Question:
-- Which order status generates the most revenue?
-- ==========================================

SELECT

    o.order_status,

    ROUND(SUM(op.payment_value),2) AS revenue

FROM orders o

JOIN order_payments op
ON o.order_id = op.order_id

GROUP BY o.order_status

ORDER BY revenue DESC;

-- ==========================================
-- Business Question:
-- Which payment method contributes the highest revenue?
-- ==========================================

SELECT

    payment_type,

    ROUND(SUM(payment_value),2) AS revenue

FROM order_payments

GROUP BY payment_type

ORDER BY revenue DESC;

-- ==========================================
-- Business Question:
-- Which orders generated the highest revenue?
-- ==========================================

SELECT

    order_id,

    ROUND(SUM(payment_value),2) AS revenue

FROM order_payments

GROUP BY order_id

ORDER BY revenue DESC

LIMIT 10;

-- ==========================================
-- Business Question:
-- Which customer states generate the most revenue?
-- ==========================================

SELECT

    c.customer_state,

    ROUND(SUM(op.payment_value),2) AS revenue

FROM customers c

JOIN orders o
ON c.customer_id = o.customer_id

JOIN order_payments op
ON o.order_id = op.order_id

GROUP BY c.customer_state

ORDER BY revenue DESC;

-- ==========================================
-- Business Question:
-- Which seller states generate the most revenue?
-- ==========================================

SELECT

    s.seller_state,

    ROUND(SUM(oi.price),2) AS revenue

FROM sellers s

JOIN order_items oi
ON s.seller_id = oi.seller_id

GROUP BY s.seller_state

ORDER BY revenue DESC;

-- ==========================================
-- Business Question:
-- Who are the top 10 sellers by revenue?
-- ==========================================

SELECT

    seller_id,

    ROUND(SUM(price),2) AS revenue

FROM order_items

GROUP BY seller_id

ORDER BY revenue DESC

LIMIT 10;

-- ==========================================
-- Business Question:
-- Which product categories generate the highest revenue?
-- ==========================================

SELECT

    ct.product_category_name_english AS category,

    ROUND(SUM(oi.price),2) AS revenue

FROM order_items oi

JOIN products p
ON oi.product_id = p.product_id

JOIN category_translation ct
ON p.product_category_name = ct.product_category_name

GROUP BY category

ORDER BY revenue DESC;

--Top 10 seller ranking
SELECT

    seller_id,
	Round(Sum(price),2) as Revenue,
	
	Rank() Over(Order By Sum(price) Desc) as seller_rank

	from order_items
	group by seller_id;

--Top 10 Product Categories

SELECT

    ct.product_category_name_english,

    ROUND(SUM(oi.price),2) AS revenue

FROM order_items oi

JOIN products p
ON oi.product_id = p.product_id

JOIN category_translation ct
ON p.product_category_name = ct.product_category_name

GROUP BY ct.product_category_name_english

ORDER BY revenue DESC

LIMIT 10;

-- Bottom 10 Product Categories
SELECT

    ct.product_category_name_english,

    ROUND(SUM(oi.price),2) AS revenue

FROM order_items oi

JOIN products p
ON oi.product_id = p.product_id

JOIN category_translation ct
ON p.product_category_name = ct.product_category_name

GROUP BY ct.product_category_name_english

ORDER BY revenue ASC

LIMIT 10;