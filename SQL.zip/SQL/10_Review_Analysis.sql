-- ==========================================
-- Business Question:
-- What is the average customer review score?
-- ==========================================

SELECT
    ROUND(AVG(review_score),2) AS average_rating
FROM order_reviews;

--Review Score Distribution

SELECT

    review_score,

    COUNT(*) AS total_reviews

FROM order_reviews

GROUP BY review_score

ORDER BY review_score;

--Rating by Product Category ⭐
SELECT

    ct.product_category_name_english,

    ROUND(AVG(r.review_score),2) AS average_rating

FROM order_reviews r

JOIN orders o
ON r.order_id = o.order_id

JOIN order_items oi
ON o.order_id = oi.order_id

JOIN products p
ON oi.product_id = p.product_id

JOIN category_translation ct
ON p.product_category_name = ct.product_category_name

GROUP BY ct.product_category_name_english

HAVING COUNT(*) >= 100

ORDER BY average_rating DESC;


--Rating vs Delivery Time ⭐⭐⭐

SELECT

CASE

WHEN
(order_delivered_customer_date::date -
order_purchase_timestamp::date)<=5

THEN '0-5 Days'

WHEN
(order_delivered_customer_date::date -
order_purchase_timestamp::date)<=10

THEN '6-10 Days'

WHEN
(order_delivered_customer_date::date -
order_purchase_timestamp::date)<=15

THEN '11-15 Days'

ELSE '15+ Days'

END delivery_time,

ROUND(

AVG(review_score),

2

) average_rating

FROM orders o

JOIN order_reviews r

ON o.order_id=r.order_id

WHERE order_delivered_customer_date IS NOT NULL

GROUP BY delivery_time

ORDER BY delivery_time;