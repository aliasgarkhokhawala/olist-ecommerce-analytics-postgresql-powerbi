COPY customers
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_customers_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY orders
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_orders_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY order_items
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_order_items_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY products
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_products_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY sellers
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_sellers_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY order_payments
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_order_payments_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY order_reviews
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_order_reviews_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY geolocation
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\olist_geolocation_dataset.csv'
DELIMITER ','
CSV HEADER;

COPY category_translation
FROM 'C:\Users\Aliasgar Khokhawala\OneDrive\Desktop\Data Analyst\Olist-Ecommerce-Analytics\Dataset\product_category_name_translation.csv'
DELIMITER ','
CSV HEADER;