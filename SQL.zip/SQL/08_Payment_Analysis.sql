-- ==========================================
-- Business Question:
-- Which payment methods are used most frequently?
-- ==========================================

SELECT

    payment_type,

    COUNT(*) AS total_transactions

FROM order_payments

GROUP BY payment_type

ORDER BY total_transactions DESC;

-- ==========================================
-- Business Question:
-- Which payment method generates the highest revenue?
-- ==========================================

SELECT

    payment_type,

    ROUND(SUM(payment_value),2) AS revenue

FROM order_payments

GROUP BY payment_type

ORDER BY revenue DESC;

-- ==========================================
--Average Payment by Payment Type
-- ==========================================

SELECT

    payment_type,

    ROUND(AVG(payment_value),2) AS average_payment

FROM order_payments

GROUP BY payment_type

ORDER BY average_payment DESC;

-- ==========================================
--Payment Method Contribution %
-- ==========================================

SELECT

    payment_type,

    ROUND(SUM(payment_value),2) AS revenue,

    ROUND(

        100*SUM(payment_value)

        /

        SUM(SUM(payment_value)) OVER(),

        2

    ) AS revenue_percentage

FROM order_payments

GROUP BY payment_type

ORDER BY revenue DESC;

-- ==========================================
--Installment Distribution
-- ==========================================

SELECT

    payment_installments,

    COUNT(*) AS total_orders

FROM order_payments

GROUP BY payment_installments

ORDER BY payment_installments;

-- ==========================================
--Average Installments
-- ==========================================

SELECT

ROUND(

AVG(payment_installments),

2

) AS average_installments

FROM order_payments;

-- ==========================================
--Revenue by Installments
-- ==========================================

SELECT

payment_installments,

ROUND(

SUM(payment_value),

2

) revenue

FROM order_payments

GROUP BY payment_installments

ORDER BY payment_installments;

-- ==========================================
--Monthly Payment Revenue
-- ==========================================
SELECT

TO_CHAR(

o.order_purchase_timestamp,

'YYYY-MM'

) AS month,

ROUND(

SUM(op.payment_value),

2

) revenue

FROM orders o

JOIN order_payments op

ON o.order_id=op.order_id

GROUP BY month

ORDER BY month;

-- ==========================================
--Highest Payment Methods Ranking
-- ==========================================

SELECT

payment_type,

ROUND(

SUM(payment_value),

2

) revenue,

RANK() OVER(

ORDER BY SUM(payment_value) DESC

) payment_rank

FROM order_payments

GROUP BY payment_type;

-- ==========================================
--Payment Classification
-- ==========================================

SELECT

payment_type,

ROUND(

SUM(payment_value),

2

) revenue,

CASE

WHEN SUM(payment_value)>=8000000 THEN 'Excellent'

WHEN SUM(payment_value)>=3000000 THEN 'Good'

WHEN SUM(payment_value)>=1000000 THEN 'Average'

ELSE 'Low'

END payment_level

FROM order_payments

GROUP BY payment_type

ORDER BY revenue DESC;

-- ==========================================
--Monthly Revenue Growth
-- ==========================================

WITH monthly_sales AS (

SELECT

TO_CHAR(

o.order_purchase_timestamp,

'YYYY-MM'

) month_name,

SUM(op.payment_value) revenue

FROM orders o

JOIN order_payments op

ON o.order_id=op.order_id

GROUP BY month_name

)

SELECT

month_name,

ROUND(revenue,2) revenue,

ROUND(

LAG(revenue) OVER(

ORDER BY month_name

),

2

) previous_month,

ROUND(

revenue-

LAG(revenue) OVER(

ORDER BY month_name

),

2

) growth

FROM monthly_sales;

-- ==========================================
--Running Total Revenue
-- ==========================================

WITH monthly_sales AS (

SELECT

TO_CHAR(

o.order_purchase_timestamp,

'YYYY-MM'

) month_name,

SUM(op.payment_value) revenue

FROM orders o

JOIN order_payments op

ON o.order_id=op.order_id

GROUP BY month_name

)

SELECT

month_name,

ROUND(revenue,2) revenue,

ROUND(

SUM(revenue) OVER(

ORDER BY month_name

),

2

) running_total

FROM monthly_sales;