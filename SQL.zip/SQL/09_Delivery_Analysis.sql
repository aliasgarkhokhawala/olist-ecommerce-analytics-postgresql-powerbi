
-- ==========================================
-- Business Question:
-- What is the average delivery time (in days)?
-- ==========================================

SELECT
    ROUND(
        AVG(
            order_delivered_customer_date::date -
            order_purchase_timestamp::date
        ),
        2
    ) AS avg_delivery_days
FROM orders
WHERE order_delivered_customer_date IS NOT NULL;

-- ==========================================
--Fastest Delivery
-- ==========================================

SELECT
    order_id,
    order_purchase_timestamp,
    order_delivered_customer_date,
    (
        order_delivered_customer_date::date -
        order_purchase_timestamp::date
    ) AS delivery_days
FROM orders
WHERE order_delivered_customer_date IS NOT NULL
ORDER BY delivery_days
LIMIT 10;


-- ==========================================
--Slowest Delivery
-- ==========================================

SELECT
    order_id,
    order_purchase_timestamp,
    order_delivered_customer_date,
    (
        order_delivered_customer_date::date -
        order_purchase_timestamp::date
    ) AS delivery_days
FROM orders
WHERE order_delivered_customer_date IS NOT NULL
ORDER BY delivery_days DESC
LIMIT 10;

-- ==========================================
--Late Deliveries
-- ==========================================
SELECT
    COUNT(*) AS late_orders
FROM orders
WHERE order_delivered_customer_date >
      order_estimated_delivery_date;

-- ==========================================
--On-Time vs Late Deliveries
-- ==========================================

SELECT

CASE

WHEN order_delivered_customer_date <= order_estimated_delivery_date

THEN 'On Time'

ELSE 'Late'

END AS delivery_status,

COUNT(*) AS total_orders

FROM orders

WHERE order_delivered_customer_date IS NOT NULL

GROUP BY delivery_status;


-- ==========================================
-- Business Question:
-- Which customer states have the longest average delivery time?
-- ==========================================

SELECT

    c.customer_state,

    ROUND(
        AVG(
            o.order_delivered_customer_date::date -
            o.order_purchase_timestamp::date
        ),
        2
    ) AS avg_delivery_days

FROM customers c

JOIN orders o
ON c.customer_id = o.customer_id

WHERE o.order_delivered_customer_date IS NOT NULL

GROUP BY c.customer_state

ORDER BY avg_delivery_days DESC;


-- ==========================================
--Average Delivery Time by Seller State
-- ==========================================

SELECT

    s.seller_state,

    ROUND(
        AVG(
            o.order_delivered_customer_date::date -
            o.order_purchase_timestamp::date
        ),
        2
    ) AS avg_delivery_days

FROM sellers s

JOIN order_items oi
ON s.seller_id = oi.seller_id

JOIN orders o
ON oi.order_id = o.order_id

WHERE o.order_delivered_customer_date IS NOT NULL

GROUP BY s.seller_state

ORDER BY avg_delivery_days DESC;


--Delivery Delay (Days)

SELECT

    order_id,

    order_estimated_delivery_date,

    order_delivered_customer_date,

    (
        order_delivered_customer_date::date -
        order_estimated_delivery_date::date
    ) AS delay_days

FROM orders

WHERE order_delivered_customer_date IS NOT NULL

ORDER BY delay_days DESC;


--Top 10 Most Delayed Orders

SELECT

order_id,

order_purchase_timestamp,

order_estimated_delivery_date,

order_delivered_customer_date,

(

order_delivered_customer_date::date -

order_estimated_delivery_date::date

) delay_days

FROM orders

WHERE order_delivered_customer_date IS NOT NULL

ORDER BY delay_days DESC

LIMIT 10;


--Delivery Performance Percentage

SELECT

ROUND(

100.0 *

SUM(

CASE

WHEN order_delivered_customer_date<=order_estimated_delivery_date

THEN 1

ELSE 0

END

)

/

COUNT(*),

2

) AS on_time_percentage

FROM orders

WHERE order_delivered_customer_date IS NOT NULL;


--Delivery Status Distribution

SELECT

CASE

WHEN order_delivered_customer_date<order_estimated_delivery_date

THEN 'Early'

WHEN order_delivered_customer_date=order_estimated_delivery_date

THEN 'On Time'

ELSE 'Late'

END delivery_status,

COUNT(*) total_orders

FROM orders

WHERE order_delivered_customer_date IS NOT NULL

GROUP BY delivery_status;

--Monthly Average Delivery Time

SELECT

TO_CHAR(

order_purchase_timestamp,

'YYYY-MM'

) month_name,

ROUND(

AVG(

order_delivered_customer_date::date -

order_purchase_timestamp::date

),

2

) avg_delivery_days

FROM orders

WHERE order_delivered_customer_date IS NOT NULL

GROUP BY month_name

ORDER BY month_name;

--Delivery Ranking by Seller State

SELECT

s.seller_state,

ROUND(

AVG(

o.order_delivered_customer_date::date -

o.order_purchase_timestamp::date

),

2

) avg_delivery,

RANK() OVER(

ORDER BY

AVG(

o.order_delivered_customer_date::date -

o.order_purchase_timestamp::date

)

) delivery_rank

FROM sellers s

JOIN order_items oi

ON s.seller_id=oi.seller_id

JOIN orders o

ON oi.order_id=o.order_id

WHERE o.order_delivered_customer_date IS NOT NULL

GROUP BY s.seller_state;