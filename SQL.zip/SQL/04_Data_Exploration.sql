SELECT COUNT(*) AS total_customers
FROM customers;

select count(Distinct customer_unique_id) as Unique_Customer from customers;

SELECT COUNT(*) AS total_orders
FROM orders;

SELECT COUNT(*) AS total_sellers
FROM sellers;

SELECT COUNT(*) AS total_products
FROM products;

SELECT COUNT(DISTINCT product_category_name) AS total_categories
FROM products;

SELECT
    MIN(order_purchase_timestamp) AS first_order,
    MAX(order_purchase_timestamp) AS last_order
FROM orders;
--Order Status Distribution
SELECT
    order_status,
    COUNT(*) AS total_orders
FROM orders
GROUP BY order_status
ORDER BY total_orders DESC;
--Customers by State
SELECT
    customer_state,
    COUNT(*) AS customers
FROM customers
GROUP BY customer_state
ORDER BY customers DESC;
--Sellers by State
SELECT
    seller_state,
    COUNT(*) AS sellers
FROM sellers
GROUP BY seller_state
ORDER BY sellers DESC;

--Products by Category
SELECT
	product_category_name,
	count(*) as total_products
FROM products
GROUP BY product_category_name
ORDER BY total_products DESC;

--Average Payment Value
SELECT
    ROUND(AVG(payment_value),2) AS avg_payment
FROM order_payments;

--Highest Payment
SELECT
    MAX(payment_value) AS highest_payment
FROM order_payments;

--Lowest Payment
SELECT
    MIN(payment_value) AS lowest_payment
FROM order_payments;

--Average Review Score
SELECT
    ROUND(AVG(review_score),2) AS average_rating
FROM order_reviews;
