-- ==========================================
-- Business Question:
-- How many sellers are registered?
-- ==========================================

SELECT COUNT(*) AS total_sellers
FROM sellers;

-- ==========================================
-- Business Question:
-- Which sellers generate the highest revenue?
-- ==========================================

SELECT

    oi.seller_id,

    ROUND(SUM(oi.price),2) AS revenue

FROM order_items oi

GROUP BY oi.seller_id

ORDER BY revenue DESC

LIMIT 10;

-- ==========================================
-- Business Question:
-- Which sellers generate the lowest revenue?
-- ==========================================

SELECT

    oi.seller_id,

    ROUND(SUM(oi.price),2) AS revenue

FROM order_items oi

GROUP BY oi.seller_id

ORDER BY revenue ASC

LIMIT 10;

-- ==========================================
-- Business Question:
-- How many sellers are located in each state?
-- ==========================================

SELECT

    seller_state,

    COUNT(*) AS total_sellers

FROM sellers

GROUP BY seller_state

ORDER BY total_sellers DESC;


-- ==========================================
-- Business Question:
-- Which seller states generate the highest revenue?
-- ==========================================

SELECT

    s.seller_state,

    ROUND(SUM(oi.price),2) AS revenue

FROM sellers s

JOIN order_items oi
ON s.seller_id = oi.seller_id

GROUP BY s.seller_state

ORDER BY revenue DESC;


-- ==========================================
-- Business Question:
-- How many orders has each seller handled?
-- ==========================================

SELECT

    seller_id,

    COUNT(DISTINCT order_id) AS total_orders

FROM order_items

GROUP BY seller_id

ORDER BY total_orders DESC;


-- ==========================================
-- Business Question:
-- Rank sellers based on total revenue.
-- ==========================================

SELECT

    seller_id,

    ROUND(SUM(price),2) AS revenue,

    RANK() OVER(
        ORDER BY SUM(price) DESC
    ) AS seller_rank

FROM order_items

GROUP BY seller_id;

-- ==========================================
--Top Seller in Each State
-- ==========================================

WITH seller_revenue AS (

SELECT

    s.seller_state,

    oi.seller_id,

    SUM(oi.price) AS revenue

FROM sellers s

JOIN order_items oi
ON s.seller_id = oi.seller_id

GROUP BY
    s.seller_state,
    oi.seller_id

)

SELECT *

FROM(

SELECT

    seller_state,

    seller_id,

    ROUND(revenue,2) AS revenue,

    ROW_NUMBER() OVER(

        PARTITION BY seller_state

        ORDER BY revenue DESC

    ) AS rn

FROM seller_revenue

)t

WHERE rn=1;

-- ==========================================
--Seller Revenue Contribution (%)
-- ==========================================

SELECT

    seller_id,

    ROUND(SUM(price),2) AS revenue,

    ROUND(

        100*SUM(price)/
        SUM(SUM(price)) OVER(),

        2

    ) AS contribution_percentage

FROM order_items

GROUP BY seller_id

ORDER BY revenue DESC;


--Seller Performance Classification

WITH seller_sales AS (

SELECT

seller_id,

SUM(price) revenue

FROM order_items

GROUP BY seller_id

)

SELECT

seller_id,

ROUND(revenue,2) revenue,

CASE

WHEN revenue>=50000 THEN 'Excellent'

WHEN revenue>=20000 THEN 'Good'

WHEN revenue>=10000 THEN 'Average'

ELSE 'Needs Improvement'

END AS performance

FROM seller_sales

ORDER BY revenue DESC;

-- ==========================================
--Average Order Value Per Seller
-- ==========================================


SELECT

seller_id,

ROUND(

SUM(price)/COUNT(DISTINCT order_id),

2

) AS average_order_value

FROM order_items

GROUP BY seller_id

ORDER BY average_order_value DESC;