--Monthly Revenue Growth (LAG)

WITH monthly_sales AS (

SELECT

TO_CHAR(

o.order_purchase_timestamp,

'YYYY-MM'

) month_name,

SUM(op.payment_value) revenue

FROM orders o

JOIN order_payments op

ON o.order_id=op.order_id

GROUP BY month_name

)

SELECT

month_name,

ROUND(revenue,2),

ROUND(

LAG(revenue)

OVER(

ORDER BY month_name

),

2

) previous_month,

ROUND(

100*

(revenue-

LAG(revenue) OVER(ORDER BY month_name))

/

LAG(revenue) OVER(ORDER BY month_name),

2

) growth_percentage

FROM monthly_sales;


--Running Revenue

WITH monthly_sales AS (

SELECT

TO_CHAR(order_purchase_timestamp,'YYYY-MM') month_name,

SUM(payment_value) revenue

FROM orders o

JOIN order_payments op

ON o.order_id=op.order_id

GROUP BY month_name

)

SELECT

month_name,

ROUND(revenue,2),

ROUND(

SUM(revenue)

OVER(

ORDER BY month_name

),

2

) running_revenue

FROM monthly_sales;

--Moving Average (3 Months)

WITH monthly_sales AS (

SELECT

TO_CHAR(order_purchase_timestamp,'YYYY-MM') month_name,

SUM(payment_value) revenue

FROM orders o

JOIN order_payments op

ON o.order_id=op.order_id

GROUP BY month_name

)

SELECT

month_name,

ROUND(revenue,2),

ROUND(

AVG(revenue)

OVER(

ORDER BY month_name

ROWS BETWEEN 2 PRECEDING AND CURRENT ROW

),

2

) moving_average

FROM monthly_sales;


--Top Seller in Every State

WITH seller_sales AS (

SELECT

s.seller_state,

s.seller_id,

SUM(oi.price) revenue

FROM sellers s

JOIN order_items oi

ON s.seller_id=oi.seller_id

GROUP BY s.seller_state,s.seller_id

)

SELECT *

FROM(

SELECT

seller_state,

seller_id,

ROUND(revenue,2),

ROW_NUMBER()

OVER(

PARTITION BY seller_state

ORDER BY revenue DESC

) rn

FROM seller_sales

)t

WHERE rn=1;


--Top Customer in Every State

WITH customer_sales AS (

SELECT

customer_state,

customer_unique_id,

SUM(payment_value) revenue

FROM customers c

JOIN orders o

ON c.customer_id=o.customer_id

JOIN order_payments op

ON o.order_id=op.order_id

GROUP BY customer_state,customer_unique_id

)

SELECT *

FROM(

SELECT

customer_state,

customer_unique_id,

ROUND(revenue,2),

ROW_NUMBER()

OVER(

PARTITION BY customer_state

ORDER BY revenue DESC

) rn

FROM customer_sales

)t

WHERE rn=1;